=== MVPWP CPT Plugin ===
Requires: WordPress
Author: Brad Williams

== Description ==

Creates a Projects custom post type


